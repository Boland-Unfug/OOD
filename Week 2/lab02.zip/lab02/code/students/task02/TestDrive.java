package students.task02;


interface ElectronicOrderBook{
    public void orderBurger(int quantity); 
    public void orderFries(char size) ; // s -> small, m -> medium, l -> large
    public void orderCombo(int quantity);
    public double getPrice();
    
}


class BurgerShopA implements ElectronicOrderBook{

	private double burgerPrice; // standard size
	private double friesPrice;
	private double currentPrice;
	
	BurgerShopA() {
		burgerPrice = 10.5;
		friesPrice = 2.5; // s -> small size, m -> 2 * s, l -> 3 * s
		currentPrice = 0.0;
		
		System.out.println("Hello there! We are ready to take orders from you ...\n");
		
	}
	@Override
	public void orderBurger(int quantity) {
		
		System.out.println("Thanks! we are preparing your ordered burger(s) ...");
        currentPrice += quantity * burgerPrice; 	
		
	}

	@Override
	public void orderFries(char size) {
		
		System.out.println("Thanks! we are preparing your ordered fries...");
		if(size == 's')
			currentPrice += friesPrice;
		else if (size == 'l')
			currentPrice += 2 * friesPrice;
		else
			currentPrice += 3 * friesPrice;
	}

	@Override
	public void orderCombo(int quantity) {
		orderBurger(quantity);
		orderFries('m');
	}

	@Override
	public double getPrice() {
		
		double cprice = currentPrice;
		currentPrice = 0.0;
		return cprice;
		
	}
	
	
}


public class TestDrive {

	public static void main(String[] args) {
		
		BurgerShopA bg1= new BurgerShopA();
		
		bg1.orderBurger(3);
		bg1.orderFries('m');
		System.out.println("\n ** Please pay "+ bg1.getPrice() + " to the counter for your order.\n");
		
		
		bg1.orderCombo(2);
		System.out.println("\n ** Please pay "+ bg1.getPrice() + " to the counter for your order.\n");

	}
	
	
}
