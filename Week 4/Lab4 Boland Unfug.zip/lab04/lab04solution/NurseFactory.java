package lab04solution;

import robot.*;

public class NurseFactory extends FactoryInterface {
    public Robot buildARobot(String name){
        return new NurseRobot(name);
    }

    public void testYourRobot(Robot r){
        if(r != null)
            r.showExpertise();
    }
}