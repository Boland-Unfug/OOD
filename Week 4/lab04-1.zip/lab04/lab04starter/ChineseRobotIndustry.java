package lab04starter;

import robot.*;

public class ChineseRobotIndustry{
	
	
	
}
