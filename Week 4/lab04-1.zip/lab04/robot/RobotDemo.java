package robot;

public class RobotDemo{
	
	public static void main(String[] args) {
		
		
		/* create two robot instances: one MathematicianRobot and one NLPResearcher */
		/*
		*/
	
	}
	
}
