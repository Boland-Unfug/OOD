package factorypattern.factorymethod3;

public interface Shape {
	   void draw();
	}