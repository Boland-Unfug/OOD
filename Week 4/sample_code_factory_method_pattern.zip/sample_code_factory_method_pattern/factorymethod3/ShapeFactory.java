package factorypattern.factorymethod3;


abstract class ShapeFactory{
	
	public abstract Shape getShape(String shapeType);
}
