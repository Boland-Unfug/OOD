package trial1;

public interface Observer<T>{

	void handle();
	
}
