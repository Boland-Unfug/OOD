package trial2;

interface Observer
{
	public void handle(PropertyChangedEvent p);
}