
public interface Play {
    public void play();
}