
public interface CommandInterface {
    public void doCommand();
    public void undoCommand();
}