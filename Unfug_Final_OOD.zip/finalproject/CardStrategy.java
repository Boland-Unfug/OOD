
public interface CardStrategy {
    void doStrategy(Player player, Player target);
}